package com.ProductCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
